-- ============================================
-- BARBERSHOP SaaS - SCRIPT SQL COMPLETO
-- Base de datos: PostgreSQL
-- ============================================

-- ============================================
-- EXTENSIONES REQUERIDAS
-- ============================================
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================
-- NÚCLEO OPERATIVO
-- ============================================

-- Tabla: negocios
CREATE TABLE negocios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nombre VARCHAR(255) NOT NULL,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    estado VARCHAR(50) DEFAULT 'activo' CHECK (estado IN ('activo', 'suspendido', 'eliminado')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_negocios_estado ON negocios(estado);

-- Tabla: sucursales
CREATE TABLE sucursales (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    negocio_id UUID NOT NULL REFERENCES negocios(id) ON DELETE CASCADE,
    nombre VARCHAR(255) NOT NULL,
    direccion VARCHAR(500) NOT NULL,
    telefono VARCHAR(20) NOT NULL,
    horario_apertura TIME NOT NULL,
    horario_cierre TIME NOT NULL,
    activa BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_sucursales_negocio_id ON sucursales(negocio_id);
CREATE INDEX idx_sucursales_activa ON sucursales(activa);

-- Tabla: roles
CREATE TABLE roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    negocio_id UUID NOT NULL REFERENCES negocios(id) ON DELETE CASCADE,
    nombre VARCHAR(50) NOT NULL,
    descripcion VARCHAR(255),
    activo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(negocio_id, nombre)
);

CREATE INDEX idx_roles_negocio_id ON roles(negocio_id);

-- Tabla: usuarios
CREATE TABLE usuarios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    negocio_id UUID NOT NULL REFERENCES negocios(id) ON DELETE CASCADE,
    sucursal_id UUID REFERENCES sucursales(id) ON DELETE SET NULL,
    rol_id UUID NOT NULL REFERENCES roles(id) ON DELETE RESTRICT,
    nombre VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    es_super_admin BOOLEAN DEFAULT false,
    activo BOOLEAN DEFAULT true,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_usuarios_negocio_id ON usuarios(negocio_id);
CREATE INDEX idx_usuarios_sucursal_id ON usuarios(sucursal_id);
CREATE INDEX idx_usuarios_email ON usuarios(email);
CREATE INDEX idx_usuarios_activo ON usuarios(activo);

-- Tabla: empleados
CREATE TABLE empleados (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    usuario_id UUID NOT NULL UNIQUE REFERENCES usuarios(id) ON DELETE CASCADE,
    sucursal_id UUID NOT NULL REFERENCES sucursales(id) ON DELETE CASCADE,
    porcentaje_comision NUMERIC(5,2) DEFAULT 0.00,
    activo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_empleados_sucursal_id ON empleados(sucursal_id);
CREATE INDEX idx_empleados_activo ON empleados(activo);

-- Tabla: disponibilidades
CREATE TABLE disponibilidades (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    empleado_id UUID NOT NULL REFERENCES empleados(id) ON DELETE CASCADE,
    dia_semana SMALLINT NOT NULL CHECK (dia_semana >= 0 AND dia_semana <= 6),
    hora_inicio TIME NOT NULL,
    hora_fin TIME NOT NULL,
    activa BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_disponibilidades_empleado_id ON disponibilidades(empleado_id);
CREATE INDEX idx_disponibilidades_dia_semana ON disponibilidades(dia_semana);

-- Tabla: clientes
CREATE TABLE clientes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    negocio_id UUID NOT NULL REFERENCES negocios(id) ON DELETE CASCADE,
    sucursal_id UUID NOT NULL REFERENCES sucursales(id) ON DELETE CASCADE,
    nombre VARCHAR(255) NOT NULL,
    telefono VARCHAR(20),
    fecha_nacimiento DATE,
    notas TEXT,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    activo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_clientes_negocio_id ON clientes(negocio_id);
CREATE INDEX idx_clientes_sucursal_id ON clientes(sucursal_id);
CREATE INDEX idx_clientes_activo ON clientes(activo);

-- Tabla: servicios
CREATE TABLE servicios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sucursal_id UUID NOT NULL REFERENCES sucursales(id) ON DELETE CASCADE,
    nombre VARCHAR(255) NOT NULL,
    precio_base NUMERIC(10,2) NOT NULL,
    duracion_minutos INTEGER NOT NULL,
    activo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_servicios_sucursal_id ON servicios(sucursal_id);
CREATE INDEX idx_servicios_activo ON servicios(activo);

-- Tabla: citas
CREATE TABLE citas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    negocio_id UUID NOT NULL REFERENCES negocios(id) ON DELETE CASCADE,
    sucursal_id UUID NOT NULL REFERENCES sucursales(id) ON DELETE CASCADE,
    cliente_id UUID NOT NULL REFERENCES clientes(id) ON DELETE RESTRICT,
    empleado_id UUID NOT NULL REFERENCES empleados(id) ON DELETE RESTRICT,
    servicio_id UUID NOT NULL REFERENCES servicios(id) ON DELETE RESTRICT,
    fecha DATE NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fin TIME NOT NULL,
    estado VARCHAR(50) DEFAULT 'confirmada' CHECK (estado IN ('confirmada', 'en_proceso', 'finalizada', 'cancelada', 'no_asistio')),
    creado_por UUID NOT NULL REFERENCES usuarios(id) ON DELETE RESTRICT,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    activa BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_citas_negocio_id ON citas(negocio_id);
CREATE INDEX idx_citas_sucursal_id ON citas(sucursal_id);
CREATE INDEX idx_citas_empleado_id ON citas(empleado_id);
CREATE INDEX idx_citas_fecha ON citas(fecha);
CREATE INDEX idx_citas_estado ON citas(estado);
CREATE INDEX idx_citas_negocio_fecha ON citas(negocio_id, fecha);

-- Tabla: pagos
CREATE TABLE pagos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    cita_id UUID NOT NULL UNIQUE REFERENCES citas(id) ON DELETE CASCADE,
    negocio_id UUID NOT NULL REFERENCES negocios(id) ON DELETE CASCADE,
    precio_base NUMERIC(10,2) NOT NULL,
    precio_final NUMERIC(10,2) NOT NULL,
    metodo_pago VARCHAR(50) NOT NULL CHECK (metodo_pago IN ('efectivo', 'tarjeta', 'transferencia', 'cheque')),
    fecha_pago TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    activo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_pagos_cita_id ON pagos(cita_id);
CREATE INDEX idx_pagos_fecha_pago ON pagos(fecha_pago);
CREATE INDEX idx_pagos_negocio_id ON pagos(negocio_id);

-- Tabla: propinas
CREATE TABLE propinas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    cita_id UUID NOT NULL REFERENCES citas(id) ON DELETE CASCADE,
    empleado_id UUID NOT NULL REFERENCES empleados(id) ON DELETE RESTRICT,
    monto NUMERIC(10,2) NOT NULL,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_propinas_cita_id ON propinas(cita_id);
CREATE INDEX idx_propinas_empleado_id ON propinas(empleado_id);
CREATE INDEX idx_propinas_fecha ON propinas(fecha);

-- Tabla: comisiones
CREATE TABLE comisiones (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    cita_id UUID NOT NULL REFERENCES citas(id) ON DELETE CASCADE,
    empleado_id UUID NOT NULL REFERENCES empleados(id) ON DELETE RESTRICT,
    monto NUMERIC(10,2) NOT NULL,
    porcentaje_aplicado NUMERIC(5,2) NOT NULL,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_comisiones_cita_id ON comisiones(cita_id);
CREATE INDEX idx_comisiones_empleado_id ON comisiones(empleado_id);
CREATE INDEX idx_comisiones_fecha ON comisiones(fecha);

-- ============================================
-- NÚCLEO SaaS (Monetización)
-- ============================================

-- Tabla: planes
CREATE TABLE planes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nombre VARCHAR(50) NOT NULL,
    precio_mensual NUMERIC(10,2) NOT NULL,
    precio_anual NUMERIC(10,2) NOT NULL,
    limite_empleados INTEGER DEFAULT 5,
    limite_sucursales INTEGER DEFAULT 1,
    limite_citas_mensuales INTEGER DEFAULT 500,
    almacenamiento_mb INTEGER DEFAULT 100,
    activo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_planes_activo ON planes(activo);

-- Tabla: suscripciones
CREATE TABLE suscripciones (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    negocio_id UUID NOT NULL UNIQUE REFERENCES negocios(id) ON DELETE CASCADE,
    plan_id UUID NOT NULL REFERENCES planes(id) ON DELETE RESTRICT,
    fecha_inicio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_fin TIMESTAMP NOT NULL,
    estado VARCHAR(50) DEFAULT 'pendiente_pago' CHECK (estado IN ('pendiente_pago', 'activa', 'vencida', 'suspendida', 'cancelada')),
    auto_renovar BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_suscripciones_negocio_id ON suscripciones(negocio_id);
CREATE INDEX idx_suscripciones_estado ON suscripciones(estado);

-- Tabla: pagos_suscripcion
CREATE TABLE pagos_suscripcion (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    suscripcion_id UUID NOT NULL REFERENCES suscripciones(id) ON DELETE CASCADE,
    monto NUMERIC(10,2) NOT NULL,
    metodo_pago VARCHAR(50) NOT NULL,
    fecha_pago TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    estado VARCHAR(50) DEFAULT 'completado' CHECK (estado IN ('completado', 'pendiente', 'fallido')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_pagos_suscripcion_suscripcion_id ON pagos_suscripcion(suscripcion_id);
CREATE INDEX idx_pagos_suscripcion_fecha_pago ON pagos_suscripcion(fecha_pago);

-- ============================================
-- SEGURIDAD Y TRAZABILIDAD
-- ============================================

-- Tabla: activity_logs
CREATE TABLE activity_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    negocio_id UUID NOT NULL REFERENCES negocios(id) ON DELETE CASCADE,
    usuario_id UUID NOT NULL REFERENCES usuarios(id) ON DELETE RESTRICT,
    entidad VARCHAR(50) NOT NULL,
    entidad_id UUID NOT NULL,
    accion VARCHAR(50) NOT NULL CHECK (accion IN ('CREATE', 'UPDATE', 'DELETE', 'READ')),
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    detalles TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_activity_logs_negocio_id ON activity_logs(negocio_id);
CREATE INDEX idx_activity_logs_usuario_id ON activity_logs(usuario_id);
CREATE INDEX idx_activity_logs_fecha ON activity_logs(fecha);
CREATE INDEX idx_activity_logs_entidad ON activity_logs(entidad);

-- ============================================
-- DATOS INICIALES (OPCIONALES)
-- ============================================

-- Insertar planes de prueba
INSERT INTO planes (nombre, precio_mensual, precio_anual, limite_empleados, limite_sucursales, limite_citas_mensuales, almacenamiento_mb, activo)
VALUES 
    ('Básico', 29.99, 299.99, 3, 1, 500, 100, true),
    ('Profesional', 79.99, 799.99, 10, 5, 5000, 1000, true),
    ('Empresarial', 199.99, 1999.99, 999, 999, 999999, 10000, true)
ON CONFLICT DO NOTHING;
