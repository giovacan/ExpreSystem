-- Migration: create_initial_schema
-- CreatedAt: 2025-02-19 12:00:00
-- Description: Crear todas las tablas del sistema

-- CreateTable "negocios"
CREATE TABLE "negocios" (
    "id" TEXT NOT NULL,
    "nombre" VARCHAR(255) NOT NULL,
    "fecha_creacion" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "estado" VARCHAR(50) NOT NULL DEFAULT 'activo',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "negocios_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "idx_negocios_estado" ON "negocios"("estado");

-- CreateTable "sucursales"
CREATE TABLE "sucursales" (
    "id" TEXT NOT NULL,
    "negocio_id" TEXT NOT NULL,
    "nombre" VARCHAR(255) NOT NULL,
    "direccion" VARCHAR(500) NOT NULL,
    "telefono" VARCHAR(20) NOT NULL,
    "horario_apertura" TIME NOT NULL,
    "horario_cierre" TIME NOT NULL,
    "activa" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "sucursales_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "sucursales_negocio_id_fkey" FOREIGN KEY ("negocio_id") REFERENCES "negocios" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateIndex
CREATE INDEX "idx_sucursales_negocio_id" ON "sucursales"("negocio_id");
CREATE INDEX "idx_sucursales_activa" ON "sucursales"("activa");

-- CreateTable "roles"
CREATE TABLE "roles" (
    "id" TEXT NOT NULL,
    "negocio_id" TEXT NOT NULL,
    "nombre" VARCHAR(50) NOT NULL,
    "descripcion" VARCHAR(255),
    "activo" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "roles_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "roles_negocio_id_fkey" FOREIGN KEY ("negocio_id") REFERENCES "negocios" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "roles_negocio_id_nombre_key" UNIQUE("negocio_id", "nombre")
);

-- CreateIndex
CREATE INDEX "idx_roles_negocio_id" ON "roles"("negocio_id");

-- CreateTable "usuarios"
CREATE TABLE "usuarios" (
    "id" TEXT NOT NULL,
    "negocio_id" TEXT NOT NULL,
    "sucursal_id" TEXT,
    "rol_id" TEXT NOT NULL,
    "nombre" VARCHAR(255) NOT NULL,
    "email" VARCHAR(255) NOT NULL,
    "password_hash" VARCHAR(255) NOT NULL,
    "es_super_admin" BOOLEAN NOT NULL DEFAULT false,
    "activo" BOOLEAN NOT NULL DEFAULT true,
    "fecha_creacion" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "usuarios_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "usuarios_negocio_id_fkey" FOREIGN KEY ("negocio_id") REFERENCES "negocios" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "usuarios_sucursal_id_fkey" FOREIGN KEY ("sucursal_id") REFERENCES "sucursales" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "usuarios_rol_id_fkey" FOREIGN KEY ("rol_id") REFERENCES "roles" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "usuarios_email_key" UNIQUE("email")
);

-- CreateIndex
CREATE INDEX "idx_usuarios_negocio_id" ON "usuarios"("negocio_id");
CREATE INDEX "idx_usuarios_sucursal_id" ON "usuarios"("sucursal_id");
CREATE INDEX "idx_usuarios_email" ON "usuarios"("email");
CREATE INDEX "idx_usuarios_activo" ON "usuarios"("activo");

-- CreateTable "empleados"
CREATE TABLE "empleados" (
    "id" TEXT NOT NULL,
    "usuario_id" TEXT NOT NULL,
    "sucursal_id" TEXT NOT NULL,
    "porcentaje_comision" NUMERIC(5, 2) NOT NULL DEFAULT 0.00,
    "activo" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "empleados_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "empleados_usuario_id_fkey" FOREIGN KEY ("usuario_id") REFERENCES "usuarios" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "empleados_sucursal_id_fkey" FOREIGN KEY ("sucursal_id") REFERENCES "sucursales" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "empleados_usuario_id_key" UNIQUE("usuario_id")
);

-- CreateIndex
CREATE INDEX "idx_empleados_sucursal_id" ON "empleados"("sucursal_id");
CREATE INDEX "idx_empleados_activo" ON "empleados"("activo");

-- CreateTable "disponibilidades"
CREATE TABLE "disponibilidades" (
    "id" TEXT NOT NULL,
    "empleado_id" TEXT NOT NULL,
    "dia_semana" SMALLINT NOT NULL,
    "hora_inicio" TIME NOT NULL,
    "hora_fin" TIME NOT NULL,
    "activa" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "disponibilidades_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "disponibilidades_empleado_id_fkey" FOREIGN KEY ("empleado_id") REFERENCES "empleados" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateIndex
CREATE INDEX "idx_disponibilidades_empleado_id" ON "disponibilidades"("empleado_id");
CREATE INDEX "idx_disponibilidades_dia_semana" ON "disponibilidades"("dia_semana");

-- CreateTable "clientes"
CREATE TABLE "clientes" (
    "id" TEXT NOT NULL,
    "negocio_id" TEXT NOT NULL,
    "sucursal_id" TEXT NOT NULL,
    "nombre" VARCHAR(255) NOT NULL,
    "telefono" VARCHAR(20),
    "fecha_nacimiento" DATE,
    "notas" TEXT,
    "fecha_registro" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "activo" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "clientes_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "clientes_negocio_id_fkey" FOREIGN KEY ("negocio_id") REFERENCES "negocios" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "clientes_sucursal_id_fkey" FOREIGN KEY ("sucursal_id") REFERENCES "sucursales" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateIndex
CREATE INDEX "idx_clientes_negocio_id" ON "clientes"("negocio_id");
CREATE INDEX "idx_clientes_sucursal_id" ON "clientes"("sucursal_id");
CREATE INDEX "idx_clientes_activo" ON "clientes"("activo");

-- CreateTable "servicios"
CREATE TABLE "servicios" (
    "id" TEXT NOT NULL,
    "sucursal_id" TEXT NOT NULL,
    "nombre" VARCHAR(255) NOT NULL,
    "precio_base" NUMERIC(10, 2) NOT NULL,
    "duracion_minutos" INTEGER NOT NULL,
    "activo" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "servicios_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "servicios_sucursal_id_fkey" FOREIGN KEY ("sucursal_id") REFERENCES "sucursales" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateIndex
CREATE INDEX "idx_servicios_sucursal_id" ON "servicios"("sucursal_id");
CREATE INDEX "idx_servicios_activo" ON "servicios"("activo");

-- CreateTable "citas"
CREATE TABLE "citas" (
    "id" TEXT NOT NULL,
    "negocio_id" TEXT NOT NULL,
    "sucursal_id" TEXT NOT NULL,
    "cliente_id" TEXT NOT NULL,
    "empleado_id" TEXT NOT NULL,
    "servicio_id" TEXT NOT NULL,
    "fecha" DATE NOT NULL,
    "hora_inicio" TIME NOT NULL,
    "hora_fin" TIME NOT NULL,
    "estado" VARCHAR(50) NOT NULL DEFAULT 'confirmada',
    "creado_por" TEXT NOT NULL,
    "fecha_creacion" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "activa" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "citas_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "citas_negocio_id_fkey" FOREIGN KEY ("negocio_id") REFERENCES "negocios" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "citas_sucursal_id_fkey" FOREIGN KEY ("sucursal_id") REFERENCES "sucursales" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "citas_cliente_id_fkey" FOREIGN KEY ("cliente_id") REFERENCES "clientes" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "citas_empleado_id_fkey" FOREIGN KEY ("empleado_id") REFERENCES "empleados" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "citas_servicio_id_fkey" FOREIGN KEY ("servicio_id") REFERENCES "servicios" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "citas_creado_por_fkey" FOREIGN KEY ("creado_por") REFERENCES "usuarios" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateIndex
CREATE INDEX "idx_citas_negocio_id" ON "citas"("negocio_id");
CREATE INDEX "idx_citas_sucursal_id" ON "citas"("sucursal_id");
CREATE INDEX "idx_citas_empleado_id" ON "citas"("empleado_id");
CREATE INDEX "idx_citas_fecha" ON "citas"("fecha");
CREATE INDEX "idx_citas_estado" ON "citas"("estado");
CREATE INDEX "idx_citas_negocio_fecha" ON "citas"("negocio_id", "fecha");

-- CreateTable "pagos"
CREATE TABLE "pagos" (
    "id" TEXT NOT NULL,
    "cita_id" TEXT NOT NULL,
    "negocio_id" TEXT NOT NULL,
    "precio_base" NUMERIC(10, 2) NOT NULL,
    "precio_final" NUMERIC(10, 2) NOT NULL,
    "metodo_pago" VARCHAR(50) NOT NULL,
    "fecha_pago" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "activo" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "pagos_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "pagos_cita_id_fkey" FOREIGN KEY ("cita_id") REFERENCES "citas" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "pagos_negocio_id_fkey" FOREIGN KEY ("negocio_id") REFERENCES "negocios" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "pagos_cita_id_key" UNIQUE("cita_id")
);

-- CreateIndex
CREATE INDEX "idx_pagos_cita_id" ON "pagos"("cita_id");
CREATE INDEX "idx_pagos_fecha_pago" ON "pagos"("fecha_pago");
CREATE INDEX "idx_pagos_negocio_id" ON "pagos"("negocio_id");

-- CreateTable "propinas"
CREATE TABLE "propinas" (
    "id" TEXT NOT NULL,
    "cita_id" TEXT NOT NULL,
    "empleado_id" TEXT NOT NULL,
    "monto" NUMERIC(10, 2) NOT NULL,
    "fecha" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "propinas_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "propinas_cita_id_fkey" FOREIGN KEY ("cita_id") REFERENCES "citas" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "propinas_empleado_id_fkey" FOREIGN KEY ("empleado_id") REFERENCES "empleados" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateIndex
CREATE INDEX "idx_propinas_cita_id" ON "propinas"("cita_id");
CREATE INDEX "idx_propinas_empleado_id" ON "propinas"("empleado_id");
CREATE INDEX "idx_propinas_fecha" ON "propinas"("fecha");

-- CreateTable "comisiones"
CREATE TABLE "comisiones" (
    "id" TEXT NOT NULL,
    "cita_id" TEXT NOT NULL,
    "empleado_id" TEXT NOT NULL,
    "monto" NUMERIC(10, 2) NOT NULL,
    "porcentaje_aplicado" NUMERIC(5, 2) NOT NULL,
    "fecha" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "comisiones_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "comisiones_cita_id_fkey" FOREIGN KEY ("cita_id") REFERENCES "citas" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "comisiones_empleado_id_fkey" FOREIGN KEY ("empleado_id") REFERENCES "empleados" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateIndex
CREATE INDEX "idx_comisiones_cita_id" ON "comisiones"("cita_id");
CREATE INDEX "idx_comisiones_empleado_id" ON "comisiones"("empleado_id");
CREATE INDEX "idx_comisiones_fecha" ON "comisiones"("fecha");

-- CreateTable "planes"
CREATE TABLE "planes" (
    "id" TEXT NOT NULL,
    "nombre" VARCHAR(50) NOT NULL,
    "precio_mensual" NUMERIC(10, 2) NOT NULL,
    "precio_anual" NUMERIC(10, 2) NOT NULL,
    "limite_empleados" INTEGER NOT NULL DEFAULT 5,
    "limite_sucursales" INTEGER NOT NULL DEFAULT 1,
    "limite_citas_mensuales" INTEGER NOT NULL DEFAULT 500,
    "almacenamiento_mb" INTEGER NOT NULL DEFAULT 100,
    "activo" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "planes_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "idx_planes_activo" ON "planes"("activo");

-- CreateTable "suscripciones"
CREATE TABLE "suscripciones" (
    "id" TEXT NOT NULL,
    "negocio_id" TEXT NOT NULL,
    "plan_id" TEXT NOT NULL,
    "fecha_inicio" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "fecha_fin" TIMESTAMP(3) NOT NULL,
    "estado" VARCHAR(50) NOT NULL DEFAULT 'pendiente_pago',
    "auto_renovar" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "suscripciones_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "suscripciones_negocio_id_fkey" FOREIGN KEY ("negocio_id") REFERENCES "negocios" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "suscripciones_plan_id_fkey" FOREIGN KEY ("plan_id") REFERENCES "planes" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "suscripciones_negocio_id_key" UNIQUE("negocio_id")
);

-- CreateIndex
CREATE INDEX "idx_suscripciones_negocio_id" ON "suscripciones"("negocio_id");
CREATE INDEX "idx_suscripciones_estado" ON "suscripciones"("estado");

-- CreateTable "pagos_suscripcion"
CREATE TABLE "pagos_suscripcion" (
    "id" TEXT NOT NULL,
    "suscripcion_id" TEXT NOT NULL,
    "monto" NUMERIC(10, 2) NOT NULL,
    "metodo_pago" VARCHAR(50) NOT NULL,
    "fecha_pago" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "estado" VARCHAR(50) NOT NULL DEFAULT 'completado',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "pagos_suscripcion_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "pagos_suscripcion_suscripcion_id_fkey" FOREIGN KEY ("suscripcion_id") REFERENCES "suscripciones" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateIndex
CREATE INDEX "idx_pagos_suscripcion_suscripcion_id" ON "pagos_suscripcion"("suscripcion_id");
CREATE INDEX "idx_pagos_suscripcion_fecha_pago" ON "pagos_suscripcion"("fecha_pago");

-- CreateTable "activity_logs"
CREATE TABLE "activity_logs" (
    "id" TEXT NOT NULL,
    "negocio_id" TEXT NOT NULL,
    "usuario_id" TEXT NOT NULL,
    "entidad" VARCHAR(50) NOT NULL,
    "entidad_id" TEXT NOT NULL,
    "accion" VARCHAR(50) NOT NULL,
    "fecha" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "detalles" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "activity_logs_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "activity_logs_negocio_id_fkey" FOREIGN KEY ("negocio_id") REFERENCES "negocios" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "activity_logs_usuario_id_fkey" FOREIGN KEY ("usuario_id") REFERENCES "usuarios" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateIndex
CREATE INDEX "idx_activity_logs_negocio_id" ON "activity_logs"("negocio_id");
CREATE INDEX "idx_activity_logs_usuario_id" ON "activity_logs"("usuario_id");
CREATE INDEX "idx_activity_logs_fecha" ON "activity_logs"("fecha");
CREATE INDEX "idx_activity_logs_entidad" ON "activity_logs"("entidad");
