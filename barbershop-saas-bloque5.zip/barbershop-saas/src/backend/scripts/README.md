# Backend Scripts

Este directorio contiene scripts de utilidad para desarrollo y despliegue.

Scripts incluidos:
- seed.js → Población de datos iniciales para desarrollo
- migrations.js → Gestión de migraciones de base de datos
- backup.js → Backup de base de datos (futuro)

Uso:
npm run seed → Ejecuta seed.js
